/*----------------------------------------------------
TITLE:  Assignment X
COURSE: TDT4102 - Programming
AUTHOR: Aslak J. Strand (c)

Notes:
    - N/A
---------------------------------------------------*/

#include <iostream>
#include "std_lib_facilities.h"
using namespace std;



int main()
{
	cout << "Hello, World!\n";

	keep_window_open();
}